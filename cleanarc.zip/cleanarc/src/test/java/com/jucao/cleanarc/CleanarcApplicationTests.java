package com.jucao.cleanarc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanarcApplicationTests {

	@Test
	void contextLoads() {
	}

}
