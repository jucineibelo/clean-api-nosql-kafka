package com.jucao.cleanarc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleanarcApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleanarcApplication.class, args);
	}

}
